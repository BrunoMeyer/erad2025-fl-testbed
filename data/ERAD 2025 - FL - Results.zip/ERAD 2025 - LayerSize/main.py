import os
import pandas as pd
import matplotlib.pyplot as plt

def main():
    # List directories in the current directory (ignore files)
    directories = [d for d in os.listdir(".") if os.path.isdir(d)]
    print(directories)

    for d in directories:
        print(d)
        # Find in the directory all files that matches client_*_metrics.csv

        df_list = []
        files = []
        server_metrics_path = None
        for root, _, filenames in os.walk(d):
            for filename in filenames:
                if filename.startswith("client_") and filename.endswith("_metrics.csv"):
                    files.append(os.path.join(root, filename))
                elif filename == "server_metrics.csv":
                    server_metrics_path = os.path.join(root, filename)
        
        df_list = [pd.read_csv(f) for f in files]
        server_metrics = pd.read_csv(server_metrics_path)
        
        max_len = max([len(df) for df in df_list])
        f1_list = []
        train_time_list = []
        eval_time_list = []
        auc_list = []
        total_time_list = []
        for i in range(len(df_list)):
            right_zero_padding_size = max_len - len(df_list[i])
            print(len(df_list[i]))
            # df_list[i] = pd.concat([df_list[i], pd.DataFrame([[None]*len(df_list[i].columns)]*right_zero_padding_size, columns=df_list[i].columns)], ignore_index=True)

            df_f1 = df_list[i][['F1-Score']]
            df_train_time = df_list[i][['Training Time (s)']]
            df_eval_time = df_list[i][['Evaluation Time (s)']]
            df_auc = df_list[i][['AUC']]
            df_total_time = df_list[i][['Total Time (s)']]

            f1_list.append(df_f1)
            train_time_list.append(df_train_time)
            eval_time_list.append(df_eval_time)
            auc_list.append(df_auc)
            total_time_list.append(df_total_time)

        # Average the metrics for each round
        f1_list = pd.concat(f1_list, axis=1).mean(axis=1)
        train_time_list = pd.concat(train_time_list, axis=1).mean(axis=1)
        eval_time_list = pd.concat(eval_time_list, axis=1).mean(axis=1)
        auc_list = pd.concat(auc_list, axis=1).mean(axis=1)
        total_time_list = pd.concat(total_time_list, axis=1).mean(axis=1)
        

        # print(server_metrics)
        round_idx = server_metrics['Round']
        time_list = server_metrics['Time Since Start (s)']
        aggregation_time = server_metrics['Aggregation Time (s)']

        # Plot using index as x axis
        # fig, ax = plt.subplots(1, 1)
        # plt.show()

        print(len(f1_list), len(round_idx))
        



if __name__ == "__main__":
    main()